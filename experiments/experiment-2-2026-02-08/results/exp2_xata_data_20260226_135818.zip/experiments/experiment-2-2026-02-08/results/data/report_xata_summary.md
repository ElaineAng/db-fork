### RQ1 overview table (paste into REPORT.md)
| Backend | Total ops | Non-zero deltas | Non-zero fraction |
|---------|-----------|-----------------|-------------------|
| **Dolt** | 3,190 | 21 | 0.7% |
| **file_copy** | 3,190 | 22 | 0.7% |
| **Neon** | 1,160 | 72 | 6.2% |
| **Xata** | 1,014 | 74 | 7.3% |

### Per-key table (spine, all N aggregated)
| Backend | r=1 | r=10 | r=20 | r=50 | r=100 |
|---------|-----|------|------|------|-------|
| Dolt | 0 B | 506 B | 15 B | 101 B | 0 B |
| file_copy | 0 B | 0 B | 4 B | 16 B | 59 B |
| Neon | 614 B | 51 B | 26 B | 23 B | 13 B |
| Xata | -410 B | 181 KB | 13 KB | 24 KB | 17 KB |

### Xata digest (for narrative updates)
- Xata total ops: 1014
- Xata non-zero deltas: 74 (7.3%)
- UPDATE:
  - spine: mean delta N=1 2 KB, N=16 0 B
  - bushy: mean delta N=1 1.25 MB, N=16 0 B
  - fan_out: mean delta N=1 321 KB, N=16 0 B
- RANGE_UPDATE (r=20):
  - spine: mean delta N=1 799 KB, N=16 0 B
  - bushy: mean delta N=1 403 KB, N=16 1.57 MB
  - fan_out: mean delta N=1 1.56 MB, N=16 0 B

