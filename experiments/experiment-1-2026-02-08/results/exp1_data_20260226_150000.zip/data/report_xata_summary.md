### Data totals
- setup file count (loaded): 92
- row count: 37245

### Xata coverage
- spine: N=1,2,4,8
- bushy: N=1,2,4,8,16
- fan_out: N=1,2,4,8,16

### Xata marginal storage delta table
Note: Rows with disk_size_before=0 or disk_size_after=0 excluded (metrics API lag).
N=1 excluded entirely (no valid disk_size_before for first branch in any rep).
| N | Spine | Bushy | Fan-out |
|---|-------|-------|---------|
| 1 | — | — | — |
| 2 | 10.44 MB | 23.52 MB | 32.00 KB |
| 4 | 25.91 MB | 27.02 MB | 39.23 MB |
| 8 | 25.06 MB | 24.89 MB | 22.64 MB |
| 16 | — | 15.95 MB | 14.20 MB |

### Xata branch creation latency (mean)
| N | Spine (ms) | Bushy (ms) | Fan-out (ms) |
|---|------------|------------|--------------|
| 1 | 43097.0 | 56347.7 | 52976.4 |
| 2 | 47434.8 | 82176.6 | 77770.8 |
| 4 | 53693.2 | 37726.3 | 59214.0 |
| 8 | 54548.5 | 56832.0 | 52416.8 |
| 16 | — | 64700.0 | 44482.5 |

### Xata topology ratio at common max N
- common max N: 8
- spine/fan_out: 1.107
- bushy/fan_out: 1.099

